let div = document.querySelector('#div1')
let todosPersonagens = []
let dados = localStorage.getItem('filmes')
if(dados){
    todosPersonagens = JSON.parse(dados)
    for(i = 0; i < todosPersonagens.length; i++){
        // innetHtml para inserir informações na div
        
        
        div1.innerHTML += `
            <img src="${todosPersonagens[i][0]}">
            <h2>${todosPersonagens[i][1]}</h2>
            <p>${todosPersonagens[i][2]}</p>
            <P>${todosPersonagens[i][3]}</p>
            <P>${todosPersonagens[i][4]}</p>
            <P>${todosPersonagens[i][5]}</p>
            
        `
    }
}

function salvarVilao(event) {
    event.preventDefault()
    const informacoesPersonagem = []
    const form = document.querySelector('form')
    const input = new FormData (form)

    const imagem = input.get('imagem')
    const personagem = input.get('personagem')
    const filme = input.get('filme')
    const ator = input.get('ator')
    const descricao = input.get('descricao')
    const habilidade = input.get('habilidade')
    
    informacoesPersonagem.push(imagem, personagem, filme, ator, descricao, habilidade)
    todosPersonagens.push(informacoesPersonagem)

    localStorage.setItem('filmes', JSON.stringify(todosPersonagens))
    //puxas uma div vazia
    div1.innerHTML = ''
    for(i = 0; i < todosPersonagens.length; i++){
        // innetHtml para inserir informações na div
        
        
        div1.innerHTML += `
            <img src="${todosPersonagens[i][0]}">
            <h2>${todosPersonagens[i][1]}</h2>
            <p>${todosPersonagens[i][2]}</p>
            <P>${todosPersonagens[i][3]}</p>
            <P>${todosPersonagens[i][4]}</p>
            <P>${todosPersonagens[i][5]}</p>
            <button>excluir</button>
            
        `
    }


}


   